$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
